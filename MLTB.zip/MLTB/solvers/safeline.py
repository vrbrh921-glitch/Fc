async def safeline_captcha(page):
    try:
        element = await page.wait_for_selector("#sl-check", timeout=3000)
        if not element:
            print("[INFO] Element #sl-check not found")
            return False

        bounding_box = await element.bounding_box()
        if not bounding_box:
            print("[INFO] Failed to get element bounding box")
            return False

        coord_x = bounding_box['x']
        coord_y = bounding_box['y']
        width = bounding_box['width']
        height = bounding_box['height']

        checkbox_x = coord_x + width / 2
        checkbox_y = coord_y + height / 2
        # print(f"Clicking at: {checkbox_x}, {checkbox_y}")
        await page.mouse.click(x=checkbox_x, y=checkbox_y)

        return True

    except Exception as e:
        print(f"[ERROR] Failed to solve safeline: {e}")
        return False
