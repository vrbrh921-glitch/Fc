━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔐 ADVANCED SECURITY DETECTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ Detect Vercel Security Checkpoint  
🤖 Auto Click Cloudflare Captcha / Turnstile  
🚦 Ratelimit Detection  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
☁️ CLOUDFLARE CHALLENGE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧩 Interactive Challenge (Captcha)  
🛡️ Managed Challenge (UAM)  
📜 JavaScript Challenge  
🔄 Turnstile  
🧠 Custom Interactive Challenge (Captcha)  
⚙️ Custom Managed Challenge (UAM)  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛡️ SAFELINE PROTECTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧩 Captcha  
📜 JavaScript Challenge  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 OTHER CHALLENGES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 Vercel Challenge  
🔥 DDoS-Guard Challenge  
🌊 H-CDN Challenge  
📜 Other JavaScript Challenge  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━


instalasi
apt update -y && apt install xvfb python3-pip
curl -fsSL https://deb.nodesource.com/setup_current.x | sudo -E bash - && sudo apt-get install -y nodejs
npm i undici https-proxy-agent request hpack
pip install browserforge camoufox aiohttp --break-system-packages